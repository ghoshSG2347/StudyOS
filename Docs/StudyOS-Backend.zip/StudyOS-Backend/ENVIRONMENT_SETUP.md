# Environment setup

## Vite frontend variables (public)

Set only these in the frontend's `.env.local` and deployment frontend build settings. Because Vite embeds `VITE_*` values into browser code, they must never contain credentials:

- `VITE_CONVEX_URL`: Convex deployment URL ending in `.convex.cloud`.
- `VITE_CONVEX_SITE_URL`: matching Convex HTTP actions URL ending in `.convex.site`.
- `VITE_SITE_URL`: exact frontend origin, for example `http://localhost:5173` or `https://studyos.example`.

The Convex CLI creates/updates `CONVEX_DEPLOYMENT` locally; do not commit it.

## Convex server environment variables (secret/private)

Set with `npx convex env set NAME value` or the Convex dashboard. These are read by functions running in Convex and must not be exposed through `VITE_*`:

- `BETTER_AUTH_SECRET`: unique high-entropy secret; generate with `openssl rand -base64 32`.
- `SITE_URL`: same exact browser origin as `VITE_SITE_URL`; used as trusted origin.
- `CONVEX_SITE_URL`: deployment's `.convex.site` URL used for Better Auth base URL.
- `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`: optional until Google OAuth is enabled. Configure Google authorized redirect URI as `https://<deployment>.convex.site/api/auth/callback/google`.
- `PASSWORD_RESET_WEBHOOK_URL` and `PASSWORD_RESET_WEBHOOK_TOKEN`: optional outbound mail relay. The application deliberately does not claim email delivery if they are absent; configure a trusted email service webhook before production password reset.

For local Convex dev, use local deployment values. For production, set the matching values independently in the production Convex deployment and frontend hosting environment. Do not reuse test OAuth credentials/secrets in production.

## Setup sequence

1. Run `npx convex dev` to create/connect a deployment and generate code.
2. Set Convex server variables listed above in that deployment.
3. Put public Vite values in frontend `.env.local` (or the frontend host's build settings).
4. Configure Google callback URLs in Google Cloud Console if using Google sign-in.
5. Configure mail service delivery before advertising password reset as available.
6. Confirm CORS/trusted-origin behavior with the actual frontend domain and browser before production.
