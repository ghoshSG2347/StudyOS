import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { requireUser, forbidden, validateName } from "./lib/auth";
import { assembleTree, type FlatNode, type TreeNode, progressOf } from "./lib/tree";

async function owned(ctx: any, id: any, userId: string) { const s = await ctx.db.get(id); if (!s || s.userId !== userId) forbidden(); return s; }
async function rows(ctx: any, syllabusId: any) { return await ctx.db.query("syllabusNodes").withIndex("by_syllabusId", (q: any) => q.eq("syllabusId", syllabusId)).collect(); }
function counts(tree: TreeNode[]) { return tree.map(progressOf).reduce((a, b) => ({ totalLeaves: a.totalLeaves + b.totalLeaves, completedLeaves: a.completedLeaves + b.completedLeaves }), { totalLeaves: 0, completedLeaves: 0 }); }
function enrich(node: TreeNode): TreeNode & ReturnType<typeof progressOf> { return { ...node, ...progressOf(node), children: node.children.map(enrich) }; }
export const list = query({ args: { includeArchived: v.optional(v.boolean()) }, handler: async (ctx, args) => {
  const user = await requireUser(ctx); const docs = await ctx.db.query("syllabuses").withIndex("by_userId_updatedAt", q => q.eq("userId", user.userId)).order("desc").collect();
  const result = [];
  for (const s of docs) { if (!args.includeArchived && s.isArchived) continue; const rs = await rows(ctx, s._id); const tree = assembleTree(rs as unknown as FlatNode[]); const c = counts(tree); result.push({ ...s, ...c, percentComplete: c.totalLeaves ? Math.round(c.completedLeaves / c.totalLeaves * 100) : 0 }); }
  return result;
}});
export const get = query({ args: { syllabusId: v.id("syllabuses") }, handler: async (ctx, { syllabusId }) => { const user = await requireUser(ctx); const syllabus = await owned(ctx, syllabusId, user.userId); return syllabus; }});
export const getTree = query({ args: { syllabusId: v.id("syllabuses") }, handler: async (ctx, { syllabusId }) => {
  const user = await requireUser(ctx); const syllabus = await owned(ctx, syllabusId, user.userId); const tree = assembleTree(await rows(ctx, syllabusId) as unknown as FlatNode[]); const c = counts(tree);
  return { syllabus, tree: tree.map(enrich), ...c, percentComplete: c.totalLeaves ? Math.round(c.completedLeaves / c.totalLeaves * 100) : 0 };
}});
export const create = mutation({ args: { name: v.string(), source: v.optional(v.string()) }, handler: async (ctx, args) => { const user = await requireUser(ctx); const now = Date.now(); return await ctx.db.insert("syllabuses", { userId: user.userId, name: validateName(args.name, "Syllabus name"), source: args.source?.trim() || undefined, isArchived: false, createdAt: now, updatedAt: now }); }});
export const rename = mutation({ args: { syllabusId: v.id("syllabuses"), name: v.string() }, handler: async (ctx, args) => { const user = await requireUser(ctx); await owned(ctx, args.syllabusId, user.userId); await ctx.db.patch(args.syllabusId, { name: validateName(args.name, "Syllabus name"), updatedAt: Date.now() }); }});
export const setArchived = mutation({ args: { syllabusId: v.id("syllabuses"), isArchived: v.boolean() }, handler: async (ctx, args) => { const user = await requireUser(ctx); await owned(ctx, args.syllabusId, user.userId); await ctx.db.patch(args.syllabusId, { isArchived: args.isArchived, updatedAt: Date.now() }); }});
export const duplicate = mutation({ args: { syllabusId: v.id("syllabuses"), name: v.string() }, handler: async (ctx, args) => {
  const user = await requireUser(ctx); const src = await owned(ctx, args.syllabusId, user.userId); const old = await rows(ctx, src._id); const now = Date.now(); const newId = await ctx.db.insert("syllabuses", { userId: user.userId, name: validateName(args.name, "Syllabus name"), source: src.source, isArchived: false, createdAt: now, updatedAt: now });
  const ids = new Map<string, any>(); const pending = [...old].sort((a: any,b: any) => a.parentId ? 1 : b.parentId ? -1 : a.order-b.order);
  for (const n of pending as any[]) { const parentId = n.parentId ? ids.get(String(n.parentId)) : undefined; if (n.parentId && !parentId) throw new Error("Invalid source tree: parent missing."); const id = await ctx.db.insert("syllabusNodes", { syllabusId: newId, userId: user.userId, parentId, name: n.name, type: n.type, order: n.order, completed: n.completed, createdAt: now, updatedAt: now }); ids.set(String(n._id), id); }
  return newId;
}});
export const deleteSyllabus = mutation({ args: { syllabusId: v.id("syllabuses") }, handler: async (ctx, { syllabusId }) => {
  const user = await requireUser(ctx); await owned(ctx, syllabusId, user.userId); const ns: any[] = await rows(ctx, syllabusId);
  const notes = await ctx.db.query("nodeNotes").withIndex("by_userId", q => q.eq("userId", user.userId)).collect(); for (const n of notes) if (ns.some(x => x._id === n.nodeId)) await ctx.db.delete(n._id);
  const mats = await ctx.db.query("materials").withIndex("by_syllabusId", q => q.eq("syllabusId", syllabusId)).collect(); for (const m of mats) { await ctx.storage.delete(m.storageId); await ctx.db.delete(m._id); }
  for (const n of ns) await ctx.db.delete(n._id); await ctx.db.delete(syllabusId);
}});
