import { ConvexError } from "convex/values";
import type { QueryCtx, MutationCtx, ActionCtx } from "../_generated/server";

export type AuthUser = { userId: string; email: string; name?: string };
export async function requireUser(ctx: QueryCtx | MutationCtx | ActionCtx): Promise<AuthUser> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Sign in is required." });
  return { userId: identity.subject, email: identity.email ?? "", name: identity.name };
}
export function forbidden(): never { throw new ConvexError({ code: "FORBIDDEN", message: "The requested resource is not available." }); }
export function validateName(value: string, label = "Name"): string {
  const clean = value.trim();
  if (!clean || clean.length > 200) throw new ConvexError({ code: "INVALID_INPUT", message: `${label} must contain 1–200 characters.` });
  return clean;
}
