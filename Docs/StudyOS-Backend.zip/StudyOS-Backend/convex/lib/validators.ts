import { v } from "convex/values";
export const nodeTypeValidator = v.union(v.literal("subject"), v.literal("chapter"), v.literal("topic"), v.literal("subtopic"), v.literal("item"));
export const educationLevelValidator = v.union(v.literal("School"), v.literal("College / University"));
export const MAX_MATERIAL_BYTES = 25 * 1024 * 1024;
export const MAX_AVATAR_BYTES = 2 * 1024 * 1024;
export const ALLOWED_MIME_TYPES = new Set([
  "application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain", "text/markdown",
  "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "image/jpeg", "image/png", "image/webp",
]);
export function materialKindFor(mime: string): "pdf" | "docx" | "text" | "slides" | "image" | "other" {
  if (mime === "application/pdf") return "pdf";
  if (mime.includes("wordprocessingml")) return "docx";
  if (mime.startsWith("text/")) return "text";
  if (mime.includes("presentation") || mime === "application/vnd.ms-powerpoint") return "slides";
  if (mime.startsWith("image/")) return "image";
  return "other";
}
