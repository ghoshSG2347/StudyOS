import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { requireUser, validateName } from "./lib/auth";
import { educationLevelValidator, MAX_AVATAR_BYTES } from "./lib/validators";

const fields = {
  fullName: v.string(), avatarStorageId: v.optional(v.id("_storage")), institute: v.optional(v.string()),
  uploadIntentId: v.optional(v.id("uploadIntents")),
  educationLevel: v.optional(educationLevelValidator), schoolDetails: v.optional(v.object({ currentClass: v.string() })),
  collegeDetails: v.optional(v.object({ courseOrBranch: v.string(), currentSemester: v.string() })),
};
function normalized(args: { fullName: string; institute?: string; educationLevel?: "School" | "College / University"; schoolDetails?: { currentClass: string }; collegeDetails?: { courseOrBranch: string; currentSemester: string } }) {
  const institute = args.institute?.trim() || undefined;
  return { fullName: validateName(args.fullName, "Full name"), institute,
    educationLevel: args.educationLevel,
    schoolDetails: args.educationLevel === "School" && args.schoolDetails?.currentClass.trim() ? { currentClass: args.schoolDetails.currentClass.trim() } : undefined,
    collegeDetails: args.educationLevel === "College / University" && (args.collegeDetails?.courseOrBranch.trim() || args.collegeDetails?.currentSemester.trim()) ? { courseOrBranch: args.collegeDetails?.courseOrBranch.trim() ?? "", currentSemester: args.collegeDetails?.currentSemester.trim() ?? "" } : undefined };
}
export const get = query({ args: {}, handler: async (ctx) => {
  const user = await requireUser(ctx); const profile = await ctx.db.query("profiles").withIndex("by_userId", q => q.eq("userId", user.userId)).unique();
  if (!profile) return null;
  const avatarUrl = profile.avatarStorageId ? await ctx.storage.getUrl(profile.avatarStorageId) : null;
  return { ...profile, avatarUrl };
}});
export const generateAvatarUploadUrl = mutation({ args: {}, handler: async (ctx) => {
  const user = await requireUser(ctx);
  const uploadIntentId = await ctx.db.insert("uploadIntents", { userId: user.userId, purpose: "avatar", createdAt: Date.now() });
  return { uploadUrl: await ctx.storage.generateUploadUrl(), uploadIntentId };
}});
export const completeOnboarding = mutation({ args: fields, handler: async (ctx, args) => {
  const user = await requireUser(ctx); const now = Date.now(); const data = normalized(args);
  if (args.avatarStorageId) { const intent = args.uploadIntentId ? await ctx.db.get(args.uploadIntentId) : null; const meta = await ctx.db.system.get(args.avatarStorageId); if (!intent || intent.userId !== user.userId || intent.purpose !== "avatar" || Date.now() - intent.createdAt > 15 * 60 * 1000 || !meta || meta.size > MAX_AVATAR_BYTES || !meta.contentType?.startsWith("image/")) throw new Error("Avatar upload is invalid, expired, or exceeds 2 MB."); }
  const existing = await ctx.db.query("profiles").withIndex("by_userId", q => q.eq("userId", user.userId)).unique();
  const doc = { ...data, userId: user.userId, email: user.email, avatarStorageId: args.avatarStorageId, completedOnboarding: true, updatedAt: now };
  if (existing) { if (existing.avatarStorageId && existing.avatarStorageId !== args.avatarStorageId) await ctx.storage.delete(existing.avatarStorageId); await ctx.db.patch(existing._id, doc); if(args.uploadIntentId) await ctx.db.delete(args.uploadIntentId); return existing._id; }
  const id = await ctx.db.insert("profiles", { ...doc, createdAt: now }); if(args.uploadIntentId) await ctx.db.delete(args.uploadIntentId); return id;
}});
export const update = mutation({ args: fields, handler: async (ctx, args) => {
  const user = await requireUser(ctx); const profile = await ctx.db.query("profiles").withIndex("by_userId", q => q.eq("userId", user.userId)).unique();
  if (!profile) throw new Error("Profile not found; complete onboarding first.");
  if (args.avatarStorageId) { const intent = args.uploadIntentId ? await ctx.db.get(args.uploadIntentId) : null; const meta = await ctx.db.system.get(args.avatarStorageId); if (!intent || intent.userId !== user.userId || intent.purpose !== "avatar" || Date.now() - intent.createdAt > 15 * 60 * 1000 || !meta || meta.size > MAX_AVATAR_BYTES || !meta.contentType?.startsWith("image/")) throw new Error("Avatar upload is invalid, expired, or exceeds 2 MB."); }
  if (profile.avatarStorageId && args.avatarStorageId && profile.avatarStorageId !== args.avatarStorageId) await ctx.storage.delete(profile.avatarStorageId);
  await ctx.db.patch(profile._id, { ...normalized(args), email: user.email, avatarStorageId: args.avatarStorageId ?? profile.avatarStorageId, updatedAt: Date.now() });
  if(args.uploadIntentId) await ctx.db.delete(args.uploadIntentId);
  return profile._id;
}});
