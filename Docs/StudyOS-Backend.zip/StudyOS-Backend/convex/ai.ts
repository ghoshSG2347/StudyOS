import { action } from "./_generated/server";
import { v } from "convex/values";
import { requireUser } from "./lib/auth";
export const availability=action({args:{},handler:async(ctx)=>{await requireUser(ctx);return {available:false,reason:"AI provider integration is intentionally not configured. Core StudyOS features work without AI."};}});
export const askAboutNode=action({args:{nodeId:v.id("syllabusNodes"),question:v.string()},handler:async(ctx)=>{await requireUser(ctx);if(!process.env.AI_PROVIDER)throw new Error("AI_UNAVAILABLE: No AI provider is configured. No request was sent.");throw new Error("AI_UNAVAILABLE: Provider adapters are not implemented in this package; no request was sent.");}});
